System.register(["./instantiated-9363c489.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.gZ)}],execute:function(){}}}));
